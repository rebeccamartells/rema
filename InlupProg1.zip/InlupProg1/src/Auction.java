public class Auction {

}